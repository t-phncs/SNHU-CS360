package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

public class RegisterScreen extends AppCompatActivity {
    private EditText edtUserR, edtEmailR, edtPassR, edtPassRR;
    private Button btnRegisterR;
    private TextView tvWarnUserR, tvWarnEmailR, tvWarnPassR, tvWarnPassRR;
    private ConstraintLayout parent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_register);

        initViews();

        btnRegisterR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                initRegister();
            }
        });
    }

    private void initRegister() {
        if(validateData()) {
            showSnackBar();
        }
    }

    private void showSnackBar() {
        tvWarnUserR.setVisibility(View.GONE);
        tvWarnEmailR.setVisibility(View.GONE);
        tvWarnPassR.setVisibility(View.GONE);
        tvWarnPassRR.setVisibility(View.GONE);

        String name = edtUserR.getText().toString();
        String email = edtEmailR.getText().toString();

        String snackText = "\nName: " + name + "\nEmail: " + email;
        Log.d("RegisterScreen", "showSnackBar: Snack Bar Text" + snackText);
        Snackbar.make(parent, snackText, Snackbar.LENGTH_INDEFINITE).setAction("Dismiss", new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtUserR.setText("");
                edtEmailR.setText("");
                edtPassR.setText("");
                edtPassRR.setText("");
            }
        }).show();
    }

    private boolean validateData() {
        if (edtUserR.getText().toString().equals("")) {
            tvWarnUserR.setVisibility(View.VISIBLE);
            tvWarnUserR.setText("Enter Your Name: ");
            return false;
        }

        if (edtEmailR.getText().toString().equals("")) {
            tvWarnEmailR.setVisibility(View.VISIBLE);
            tvWarnEmailR.setText("Enter Your Email: ");
            return false;
        }

        if (edtPassR.getText().toString().equals("")) {
            tvWarnPassR.setVisibility(View.VISIBLE);
            tvWarnPassR.setText("Enter Your Password: ");
            return false;
        }

        if (edtPassRR.getText().toString().equals("")) {
            tvWarnPassRR.setVisibility(View.VISIBLE);
            tvWarnPassRR.setText("Re-Enter Your Password: ");
            return false;
        }

        if (!edtPassR.getText().toString().equals(edtPassRR.getText().toString())) {
            tvWarnPassRR.setVisibility(View.VISIBLE);
            tvWarnPassRR.setText("Password doesn't matched");
            return false;
        }
        return true;
    }


    private void initViews() {
        edtUserR = findViewById(R.id.edtUsernameR);
        edtEmailR = findViewById(R.id.edtEmailR);
        edtPassR = findViewById(R.id.edtPasswordR);
        edtPassRR = findViewById(R.id.edtPasswordRepeatR);

        tvWarnUserR = findViewById(R.id.tvWarnUserR);
        tvWarnEmailR = findViewById(R.id.tvWarnEmailR);
        tvWarnPassR = findViewById(R.id.tvWarnPassR);
        tvWarnPassRR = findViewById(R.id.tvWarnPassRR);

        btnRegisterR = findViewById(R.id.btnRegisterR);
        parent = findViewById(R.id.parent);
    }
}