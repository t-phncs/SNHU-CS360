package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private EditText edtName, edtPassword;
    private Button btnLogin, btnSignUp;

    private TextView tvUserValidate, tvPassValidate;

    private ConstraintLayout parent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, DBScreen.class);
                startActivity(intent);


            }
        });

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, RegisterScreen.class);
                startActivity(intent);
            }
        });
    }

    private void initLogin() {
        if(validateData()) {
            showSnackBar();
        }
    }

    private void showSnackBar() {
        tvUserValidate.setVisibility(View.GONE);
        tvPassValidate.setVisibility(View.GONE);

        String name = edtName.getText().toString();

        String snackText = "\nName: " + name;
        Log.d("Login Screen", "showSnackBar: Snack Bar Text" + snackText);
        Snackbar.make(parent, snackText, Snackbar.LENGTH_INDEFINITE).setAction("Dismiss", new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtName.setText("");
            }
        }).show();
    }

    private boolean validateData() {
        if (edtName.getText().toString().equals("")) {
            tvUserValidate.setVisibility(View.VISIBLE);
            tvUserValidate.setText("Enter Your Name: ");
            return false;
        }

        if (edtPassword.getText().toString().equals("")) {
            tvPassValidate.setVisibility(View.VISIBLE);
            tvPassValidate.setText("Enter Your Password: ");
            return false;
        }
        return true;
    }

    private void initViews() {
        Log.d(TAG, "initViews: Started");

        edtName = findViewById(R.id.edtUsername);
        edtPassword = findViewById(R.id.edtPassword);

        btnLogin = findViewById(R.id.btnLogin);
        btnSignUp = findViewById(R.id.btnSignUp);

        tvPassValidate = findViewById(R.id.tvPassValidate);
        tvUserValidate = findViewById(R.id.tvUserValidate);

        parent = findViewById(R.id.parent);

    }
}